pref("xpinstall.enabled",       true);
pref("xpinstall.whitelist.required", true);
